
# Project Title: Responsive Landing Page with Dynamic Navigation Bar

## Project Description
    This project is a responsive landing page featuring a dynamic navigation bar that highlights the active section while scrolling.

## Dependencies
    None

## Usage
    - Open the `index.html` file in a web browser to see the navbar and sections in action.
    - Click on a navbar item to highlight the corresponding section.

## Setup
    1. Clone or download this repository to your local machine.
    2. Open the `index.html` file in a web browser to see the demo.

## Files
    - **index.html**: The main HTML file that contains the navbar and sections.
    - **style.css**: The CSS file that contains the styles for highlighting the selected section.
    - **script.js**: The JavaScript file that contains the event listener and logic for highlighting the selected section.

## How it Works
    -The navbar highlighter uses a combination of JavaScript and CSS to highlight the selected section when a navbar item is clicked. Here's a brief overview of how it works:
    - The JavaScript code attaches an event listener to the navbar element, which listens for click events on the navbar items.
    - When a navbar item is clicked, the JavaScript code gets the corresponding section element using the `data-section` attribute and adds a CSS class to highlight the section.
    - The CSS styles define the visual appearance of the highlighted section.

## Customization
    You can customize the appearance of the highlighted section by modifying the CSS styles in the `style.css` file. You can also modify the JavaScript code in the `script.js` file to change the behavior of the navbar highlighter.