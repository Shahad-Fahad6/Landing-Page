
const navElement = document.querySelector("#nav");
const sectionList = document.querySelectorAll("section")


// a function to set the active class to the clicked link
function setActive(element) {
  const allLinks = document.querySelectorAll("a");

  allLinks.forEach(function (link) {
    link.classList.remove("active");
  });

  element.classList.add("active");
}


// a function to create the navigation items
function createNav(section) {
  // get the id of the current section
  const id = section.getAttribute("id");
  // create a list item
  const item = document.createElement("li");
  // create <a> link
  const link = document.createElement("a");
  link.href = '#'+id
  link.textContent = id.toUpperCase(); 

  // adding an event listener to the link 
  // so we can scroll to the section when clicked
  link.addEventListener("click", function (event) {
    event.preventDefault();

    setActive(link);

    const targetSection = document.querySelector('#'+id);

    if (targetSection) {
      targetSection.scrollIntoView({ behavior: "smooth" });
    }
  });

  // appending the link to the item
  item.appendChild(link);

  // appending the item to the navigation
  navElement.appendChild(item);
}

// looping through the navigation array 
sectionList.forEach(createNav);



// controlling the scroll action
document.addEventListener("scroll", function () {
  // getting all the sections
  const sections = document.querySelectorAll("section");

  // looping through the sections
  sections.forEach(function (section) {
    // getting the rect of the section
    const rect = section.getBoundingClientRect();

    // checking if the section is in the viewport
    if (rect.top <= 100 && rect.bottom >= 100) {
      // getting the id of the section
      const id = section.getAttribute("id");
      // finding the matching nav element for the section
      const activeLink = document.querySelector(`a[href="#${id}"]`);
      // setting the active class to the link
      setActive(activeLink);
    }
  });
});
